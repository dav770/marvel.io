import Firebase from './firebase';
import FirebaseContext from './context';

export default Firebase;
export { FirebaseContext };